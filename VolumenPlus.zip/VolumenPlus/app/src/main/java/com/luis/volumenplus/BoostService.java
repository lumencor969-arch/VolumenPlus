package com.luis.volumenplus;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.LoudnessEnhancer;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

/**
 * Servicio que mantiene activo el refuerzo de volumen.
 *
 * Usa LoudnessEnhancer (efecto de audio oficial de Android) de dos formas:
 *  1. Sobre la salida general (sesion 0), que funciona en la mayoria de equipos Xiaomi.
 *  2. Sobre cada reproductor que anuncie su sesion de audio (Spotify, reproductores de musica, etc.).
 */
public class BoostService extends Service {

    public static final String ACTION_START = "com.luis.volumenplus.START";
    public static final String ACTION_UPDATE = "com.luis.volumenplus.UPDATE";
    public static final String ACTION_STOP = "com.luis.volumenplus.STOP";

    public static final String PREFS = "volumen_plus";
    public static final String KEY_GAIN_DB = "gain_db";
    public static final String KEY_ENABLED = "enabled";

    private static final String TAG = "VolumenPlus";
    private static final String CHANNEL_ID = "refuerzo";
    private static final int NOTIFICATION_ID = 1;

    private LoudnessEnhancer globalEnhancer;
    private final Map<Integer, LoudnessEnhancer> sessionEnhancers = new HashMap<>();
    private int gainDb = 0;
    private boolean receiverRegistered = false;

    /** Indica si el servicio esta corriendo (para que la pantalla muestre el estado real). */
    public static volatile boolean isRunning = false;

    private final BroadcastReceiver sessionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int sessionId = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1);
            if (sessionId <= 0) {
                return;
            }
            String action = intent.getAction();
            if (AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION.equals(action)) {
                attachToSession(sessionId);
            } else if (AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION.equals(action)) {
                releaseSession(sessionId);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        registerSessionReceiver();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        gainDb = prefs.getInt(KEY_GAIN_DB, 6);

        showNotification();
        applyGain();
        isRunning = true;
        return START_STICKY;
    }

    private void applyGain() {
        int gainMillibels = gainDb * 100;

        try {
            if (globalEnhancer == null) {
                globalEnhancer = new LoudnessEnhancer(0);
            }
            globalEnhancer.setTargetGain(gainMillibels);
            globalEnhancer.setEnabled(gainDb > 0);
        } catch (Throwable t) {
            Log.w(TAG, "No se pudo aplicar el refuerzo general", t);
            globalEnhancer = null;
        }

        for (LoudnessEnhancer enhancer : sessionEnhancers.values()) {
            try {
                enhancer.setTargetGain(gainMillibels);
                enhancer.setEnabled(gainDb > 0);
            } catch (Throwable t) {
                Log.w(TAG, "No se pudo actualizar una sesion", t);
            }
        }
    }

    private void attachToSession(int sessionId) {
        if (sessionEnhancers.containsKey(sessionId)) {
            return;
        }
        try {
            LoudnessEnhancer enhancer = new LoudnessEnhancer(sessionId);
            enhancer.setTargetGain(gainDb * 100);
            enhancer.setEnabled(gainDb > 0);
            sessionEnhancers.put(sessionId, enhancer);
        } catch (Throwable t) {
            Log.w(TAG, "No se pudo conectar a la sesion " + sessionId, t);
        }
    }

    private void releaseSession(int sessionId) {
        LoudnessEnhancer enhancer = sessionEnhancers.remove(sessionId);
        if (enhancer != null) {
            try {
                enhancer.release();
            } catch (Throwable ignored) {
            }
        }
    }

    private void registerSessionReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION);
        filter.addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(sessionReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(sessionReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Refuerzo de volumen", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Muestra que Volumen+ esta activo");
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.createNotificationChannel(channel);
        }
    }

    private void showNotification() {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this, 0, openApp, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, BoostService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .setContentTitle("Volumen+ activo")
                .setContentText("Refuerzo: +" + gainDb + " dB")
                .setContentIntent(openPending)
                .addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Apagar", stopPending).build())
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (receiverRegistered) {
            try {
                unregisterReceiver(sessionReceiver);
            } catch (Throwable ignored) {
            }
            receiverRegistered = false;
        }
        if (globalEnhancer != null) {
            try {
                globalEnhancer.setEnabled(false);
                globalEnhancer.release();
            } catch (Throwable ignored) {
            }
            globalEnhancer = null;
        }
        for (LoudnessEnhancer enhancer : sessionEnhancers.values()) {
            try {
                enhancer.release();
            } catch (Throwable ignored) {
            }
        }
        sessionEnhancers.clear();

        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, false).apply();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
