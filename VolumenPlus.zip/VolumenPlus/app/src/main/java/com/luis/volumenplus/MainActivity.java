package com.luis.volumenplus;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Pantalla principal de Volumen+.
 * Permite elegir cuantos decibeles extra se suman al audio y encender/apagar el refuerzo.
 */
public class MainActivity extends Activity {

    private static final int MAX_GAIN_DB = 15;
    private static final int SAFE_GAIN_DB = 10;

    private SharedPreferences prefs;
    private TextView gainLabel;
    private TextView warningLabel;
    private Switch enableSwitch;
    private CompoundButton.OnCheckedChangeListener switchListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(BoostService.PREFS, MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }

        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Muestra el estado real (por si se apago desde la notificacion o el sistema cerro el servicio)
        if (enableSwitch != null) {
            enableSwitch.setOnCheckedChangeListener(null);
            enableSwitch.setChecked(BoostService.isRunning);
            enableSwitch.setOnCheckedChangeListener(switchListener);
        }
    }

    private ScrollView buildUi() {
        int pad = dp(20);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Refuerzo de volumen");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Suma decibeles extra al sonido de musica, videos y llamadas en altavoz. "
                + "Primero sube el volumen normal del celular al maximo y luego usa este refuerzo.");
        info.setTextSize(15);
        info.setPadding(0, dp(8), 0, dp(16));
        root.addView(info);

        enableSwitch = new Switch(this);
        enableSwitch.setText("Activar refuerzo");
        enableSwitch.setTextSize(18);
        enableSwitch.setChecked(BoostService.isRunning);
        switchListener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                prefs.edit().putBoolean(BoostService.KEY_ENABLED, isChecked).apply();
                if (isChecked) {
                    startBoost(BoostService.ACTION_START);
                } else {
                    stopBoost();
                }
            }
        };
        enableSwitch.setOnCheckedChangeListener(switchListener);
        root.addView(enableSwitch);

        gainLabel = new TextView(this);
        gainLabel.setTextSize(18);
        gainLabel.setPadding(0, dp(24), 0, dp(8));
        root.addView(gainLabel);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(MAX_GAIN_DB);
        seekBar.setProgress(prefs.getInt(BoostService.KEY_GAIN_DB, 6));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                prefs.edit().putInt(BoostService.KEY_GAIN_DB, progress).apply();
                updateGainLabel(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                if (enableSwitch.isChecked()) {
                    startBoost(BoostService.ACTION_UPDATE);
                }
            }
        });
        root.addView(seekBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        warningLabel = new TextView(this);
        warningLabel.setTextSize(14);
        warningLabel.setPadding(0, dp(4), 0, dp(16));
        root.addView(warningLabel);
        updateGainLabel(seekBar.getProgress());

        Button maxVolume = new Button(this);
        maxVolume.setText("Subir volumen multimedia al maximo");
        maxVolume.setOnClickListener(v -> setMediaVolumeToMax());
        root.addView(maxVolume);

        Button battery = new Button(this);
        battery.setText("Evitar que Xiaomi cierre la app");
        battery.setOnClickListener(v -> openAppSettings());
        root.addView(battery);

        TextView tip = new TextView(this);
        tip.setText("Consejo: en Ajustes de la app pon Ahorro de bateria en \"Sin restricciones\" "
                + "y activa \"Inicio automatico\" para que el refuerzo no se apague solo.");
        tip.setTextSize(13);
        tip.setPadding(0, dp(8), 0, 0);
        root.addView(tip);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private void updateGainLabel(int db) {
        gainLabel.setText("Refuerzo: +" + db + " dB");
        if (db > SAFE_GAIN_DB) {
            warningLabel.setText("Nivel alto: el sonido puede distorsionarse, forzar el parlante "
                    + "y danar tus oidos con audifonos. Usalo por ratos cortos.");
            warningLabel.setTextColor(Color.rgb(198, 40, 40));
        } else {
            warningLabel.setText("Nivel recomendado: hasta +" + SAFE_GAIN_DB + " dB.");
            warningLabel.setTextColor(Color.GRAY);
        }
        warningLabel.setGravity(Gravity.START);
    }

    private void startBoost(String action) {
        Intent intent = new Intent(this, BoostService.class).setAction(action);
        try {
            startForegroundService(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo iniciar el refuerzo: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            enableSwitch.setChecked(false);
        }
    }

    private void stopBoost() {
        stopService(new Intent(this, BoostService.class));
    }

    private void setMediaVolumeToMax() {
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (audio == null) {
            return;
        }
        int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI);
    }

    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
